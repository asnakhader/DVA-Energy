//method to find the csv data location
function findCsvLocNew(property_type) {
  if (property_type == "electricity_generation") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-Energy/main/energy_filtered.csv";
  }if (property_type == "Renewables") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-Energy/main/renewable-share-energy1.csv";
  }if (property_type == "co2") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-Energy/main/co-emissions-per-capita1.csv";
  }if (property_type == "continent") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-Energy/main/energy_with_continent.csv";
  }
  if (property_type == "covid") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-CSV-Files/main/30_Filtered_1.csv";
  }
  if (property_type == "deaths") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-Energy/main/death-rates-from-air-pollution1.csv";
  }
  if (property_type == "vaccination") {
    csv_loc = "https://raw.githubusercontent.com/asnakhader/DVA-CSV-Files/main/vaccinations.csv";
  }
  
  if (property_type == "population") {
    csv_loc =
      "https://raw.githubusercontent.com/mzashin/HW_F21DV/main/CourseProject/assets/Exercises/Lab4/dataset/Country-Population.csv";
  }

  if (property_type == "fertility_rate") {
    csv_loc =
      "https://raw.githubusercontent.com/mzashin/HW_F21DV/main/CourseProject/assets/Exercises/Lab4/dataset/Fertility-Rate.csv";
  }

  if (property_type == "life_expectancy") {
    csv_loc =
      "https://raw.githubusercontent.com/mzashin/HW_F21DV/main/CourseProject/assets/Exercises/Lab4/dataset/Life-Expectancy-At-Birth.csv";
  }

  if (property_type == "country_metadata") {
    csv_loc =
      "https://raw.githubusercontent.com/mzashin/HW_F21DV/main/CourseProject/assets/Exercises/Lab4/dataset/Country-Metadata.csv";
  }

  return csv_loc;
}

function combinedPropertyStatsPerYearAndProperty(year, property) {

  final_data = Promise.all([
    propertyStatsPerYear(property, year),
  ]).then(function (loadData) {
    property_1_data = loadData[0];
    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}
//can be removed if not needed
function combinedPropertyStatsPerYearOld(year) {
  property_list = ["Renewables", "fertility_rate", "life_expectancy"];

  final_data = Promise.all([
    propertyStatsPerYear(property_list[0], year),
    //propertyStatsPerYear(property_list[1], year),
    //propertyStatsPerYear(property_list[2], year),
  ]).then(function (loadData) {
    property_1_data = loadData[0];
    //property_2_data = loadData[1];
    //property_3_data = loadData[2];

    /*console.log("Combine data 1", property_1_data);
    console.log("Combine data 2", property_2_data);
    console.log("Combine data 3", property_3_data);*/

    /*property_1_data.forEach(function (record_p1) {
      var result_p2 = property_2_data.filter(function (record_p2) {
        return record_p1.country_code === record_p2.country_code;
      });

      var result_p3 = property_3_data.filter(function (record_p3) {
        return record_p1.country_code === record_p3.country_code;
      });

      delete record_p1.property_type;
      record_p1[property_list[0]] = record_p1.property_value;
      delete record_p1.property_value;
      record_p1[property_list[1]] =
        result_p2[0] !== undefined ? result_p2[0].property_value : null;
      record_p1[property_list[2]] =
        result_p3[0] !== undefined ? result_p3[0].property_value : null;
    });*/
    //console.log('Final Combined Data Per Country:',property_1_data);
    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}

function propertyStatsPerYear(property_type, year) {
  csv_loc = findCsvLocNew(property_type);

  final_data = d3.csv(csv_loc).then(function (data) {
	filtered = data.filter(function (d) {
        return d["Year"] == year;
      });
    var property_data = filtered.map(function (d) {
      return {
        country_code: d["Code"],
        country_name: d["Entity"],
        property_type: property_type,
        property_year: +year,
        property_value: +d[property_type],
      };
    });
    console.log("Final Data", property_data);
    return property_data;
  });
  return final_data;
}

function propertyStatsForAllYearsForAllCountries(property_type) {
  csv_loc = findCsvLocNew(property_type);
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
      "2000",
      "2001",
      "2002",
      "2003",
      "2004",
      "2005",
      "2006",
      "2007",
      "2008",
      "2009",
      "2010",
      "2011",
      "2012",
      "2013",
      "2014",
      "2015",
      "2016",
	  "2017",
      "2018",
      "2019",
	  "2020",
	  "2021",
    ];

    csv_loc = findCsvLocNew(property_type);
   /* data.forEach(function (d) {
      column_list.forEach(function (col, i) {
        d[col] = +d[col];
      });
    });*/

    var final_data = [];

    data.forEach(function (record) {
      //column_list.forEach(function (col, i) {
	if(record["iso_code"] != ''){
        var jsonData = {};
		 console.log("Final Data", record);
        jsonData["country_code"] = record["iso_code"];
        jsonData["country_name"] = record["country"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = record["year"];
        jsonData["property_value"] = record["electricity_generation"];
        final_data.push(jsonData);
      //});
	  }
    });
    console.log("Final Data", final_data);
    return final_data;
  });
  return final_data;
}



function propertyStatsPerCountry(property_type, country_code) {
  csv_loc = findCsvLocNew(property_type);
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
      "2000",
      "2001",
      "2002",
      "2003",
      "2004",
      "2005",
      "2006",
      "2007",
      "2008",
      "2009",
      "2010",
      "2011",
      "2012",
      "2013",
      "2014",
      "2015",
      "2016",
	  "2017",
      "2018",
      "2019",
	  "2020",
	  "2021",
    ];

    csv_loc = findCsvLocNew(property_type);
    data.forEach(function (d) {
      column_list.forEach(function (col, i) {
        d[col] = +d[col];
      });
    });


      filtered = data.filter(function (d) {
        return d["Entity"] == country_code;
      });

      var final_data = [];
      column_list.forEach(function (col, i) {
		property_data_country = filtered.filter(function (d) {
          return d["Year"] == col;
        });
        var jsonData = {};
        jsonData["country_code"] = filtered[0]["Entity"];
        jsonData["country_name"] = filtered[0]["Entity"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = +col;
        jsonData["property_value"] = +property_data_country[0][property_type];
        final_data.push(jsonData);
      });

      console.log("Final Data", final_data);
      return final_data;
    
  });
  return final_data;
}
















function combinedPropertyStatsPerYear(year, data_order) {
  property_list = ["electricity_generation", "fertility_rate", "life_expectancy"];

  final_data = Promise.all([
    propertyStatsPerYearEnergy(property_list[0], year, data_order),
   // propertyStatsPerYearOld(property_list[1], year),
    //propertyStatsPerYearOld(property_list[2], year),
  ]).then(function (loadData) {
    property_1_data = loadData[0];
   // property_2_data = loadData[1];
    //property_3_data = loadData[2];

    console.log("Combine data 1", property_1_data);
    //console.log("Combine data 2", property_2_data);
    //console.log("Combine data 3", property_3_data);

    /*property_1_data.forEach(function (record_p1) {
      var result_p2 = property_2_data.filter(function (record_p2) {
        return record_p1.country_code === record_p2.country_code;
      });

      var result_p3 = property_3_data.filter(function (record_p3) {
        return record_p1.country_code === record_p3.country_code;
      });

      delete record_p1.property_type;
      record_p1[property_list[0]] = record_p1.property_value;
      delete record_p1.property_value;
      record_p1[property_list[1]] =
        result_p2[0] !== undefined ? result_p2[0].property_value : null;
      record_p1[property_list[2]] =
        result_p3[0] !== undefined ? result_p3[0].property_value : null;
    });*/
    //console.log('Final Combined Data Per Country:',property_1_data);
    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}

function propertyStatsPerYearEnergy(property_type, year, data_order) {
  csv_loc = findCsvLocNew(property_type);
  final_data = d3.csv(csv_loc).then(function (data) {
	  filtered = data.filter(function (d) {
			return d["year"] == year && d["iso_code"] != '';
		  });
		  
	  var final_data = [];
	  
	  filtered.forEach(function (d, i) {
		var jsonData = {};
		jsonData["country_code"] = filtered[i]["iso_code"];
		jsonData["country_name"] = filtered[i]["country"];
		jsonData["property_type"] = property_type;
		jsonData["property_year"] = "2021";
		jsonData["property_value"] = filtered[i]["electricity_generation"];
		jsonData["property_value"] = filtered[i]["electricity_generation"] - filtered[i]["electricity_demand"];
		
		//jsonData["property_value"] = filtered[i]["electricity_generation"] - filtered[i]["electricity_demand"]
		/*if(data_order == "DESC"){
			jsonData["property_value"] = filtered[i]["electricity_generation"] - filtered[i]["electricity_demand"]
		}else{
			jsonData["property_value"] = filtered[i]["electricity_demand"] - filtered[i]["electricity_generation"]
		}*/
		
		final_data.push(jsonData);
	  });
	  return final_data;
  });

  /*final_data = d3.csv(csv_loc).then(function (data) {
    var property_data = data.map(function (d) {
      return {
        country_code: d["iso_code"],
        country_name: d["country"],
        property_type: property_type,
        property_year: +year,
        property_value: +d[year],
		electricity_generation: +d[year],
      };
    });
    console.log("Final Data", property_data);
    return property_data;
  });
  */
  return final_data;
}


function combinedPropertyStatsPerYearOld(year) {
  property_list = ["deaths"];

  final_data = Promise.all([
    propertyStatsPerYearOld(property_list[0])
  ]).then(function (loadData) {
    property_1_data = loadData[0];

    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}

function propertyStatsPerYearOld(property_type) {
  csv_loc = findCsvLocNew("deaths");
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
      "2019"
    ];
    
    data.forEach(function (d) {
      column_list.forEach(function (col, i) {
        d[col] = +d[col];
      });
    });
     filtered = data.filter(function (d) {
        return d["Year"] == "2019";
      });
      
      var final_data = [];
      filtered.forEach(function (d, i) {
        var jsonData = {};
        jsonData["country_code"] = filtered[i]["Code"];
        jsonData["country_name"] = filtered[i]["Entity"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = "2019";
        jsonData["property_value"] = filtered[i]["deaths"];
        
        final_data.push(jsonData);
      });
      return final_data;
  });
  return final_data;
}


function combinedPropertyStatsPerCountryOld(country_code) {
  property_list = ["electricity_generation"];

  final_data = Promise.all([
    propertyStatsPerCountryOld(property_list[0], country_code)
  ]).then(function (loadData) {
    property_1_data = loadData[0];


    console.log("Combine data 1", property_1_data);

    return property_1_data;
  });

  console.log("Final Combined Data Per Country", final_data);
  return final_data;
}

function propertyStatsPerCountryOld(property_type, country_code) {
  csv_loc = findCsvLocNew(property_type);
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
		//"Fossil",
		"Gas",
		"Hydro",
		"Oil",
		"Solar",
		"Wind",
		"Nuclear"
    ];
	
	value_list = [
	//"fossil_energy_per_capita",
	"gas_energy_per_capita",
	"hydro_energy_per_capita",
	"oil_energy_per_capita",
	"solar_energy_per_capita",
	"wind_energy_per_capita",
	"nuclear_energy_per_capita"
    ];


    filtered = data.filter(function (d) {
        return d["iso_code"] == country_code;
    });
	
      var final_data = [];
      column_list.forEach(function (col, i) {
		property_data_country = filtered.filter(function (d) {
          return d["year"] == "2021";
        });
        var jsonData = {};
		var value_item = value_list[i];
        jsonData["country_code"] = filtered[0]["iso_code"];
        jsonData["country_name"] = filtered[0]["country"];
        jsonData["property_type"] = property_type;
		jsonData["energy"] = col;
        jsonData["property_year"] = "2021";
        jsonData["value"] = +property_data_country[0][value_item];
		
		//others
		jsonData["energy_per_capita"] = filtered[0]["energy_per_capita"];
		jsonData["fossil_energy_per_capita"] = filtered[0]["fossil_energy_per_capita"];
		 jsonData["low_carbon_energy_per_capita"] = filtered[0]["low_carbon_energy_per_capita"];
		 jsonData["other_renewables_energy_per_capita"] = filtered[0]["other_renewables_energy_per_capita"];
		 jsonData["renewables_energy_per_capita"] = filtered[0]["renewables_energy_per_capita"];
		 
		
        final_data.push(jsonData);
      });
      return final_data;
    
  });
  return final_data;
}

/*
Below methods are used to filter data based on the needs of the graph being generated
*/
function combinedPropertyStatsPerYearWithMetadataLookup(year) {
  property_list = ["continent", "people_vaccinated_per_hundred", "total_deaths_per_million"];

  final_data = Promise.all([
    propertyStatsPerYearContinent(property_list[0]),
  ]).then(function (loadData) {
    property_1_data = loadData[0];
   
    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}


function propertyStatsPerYearContinent(property_type) {
  csv_loc = findCsvLocNew("continent");
  final_data = d3.csv(csv_loc).then(function (data) {
   
     filtered = data.filter(function (d) {
        return d["year"] == "2021";
      });
      
      var final_data = [];
      filtered.forEach(function (d, i) {
        var jsonData = {};
        jsonData["country_code"] = filtered[i]["iso_code"];
        jsonData["country_name"] = filtered[i]["country"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = "2021";
        jsonData["property_value"] = filtered[i]["greenhouse_gas_emissions"];
        
        //added new
         jsonData["continent"] = filtered[i]["continent"];
         jsonData["gdp_per_capita"] = filtered[i]["energy_per_capita"];
         jsonData["total_deaths_per_million"] = filtered[i]["population"];
        final_data.push(jsonData);
      });
      return final_data;
  });
  return final_data;
}


































































/*
Below methods are used to filter data based on the needs of the graph being generated
*/
function combinedPropertyStatsPerYearWithMetadataLookupNew(year) {
  property_list = ["continent", "people_vaccinated_per_hundred", "total_deaths_per_million"];

  final_data = Promise.all([
    propertyStatsPerYearNew(property_list[0]),
  ]).then(function (loadData) {
    property_1_data = loadData[0];
   
    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}

function combinedPropertyStatsPerYearNew(year) {
  property_list = ["total_cases"];

  final_data = Promise.all([
    propertyStatsPerYearNew(property_list[0])
  ]).then(function (loadData) {
    property_1_data = loadData[0];

    return property_1_data;
  });

  console.log("Final Combined Data Per Year", final_data);
  return final_data;
}

function propertyStatsPerYearNew(property_type) {
  csv_loc = findCsvLocNew("covid");
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
      "2023"
    ];
    
    data.forEach(function (d) {
      column_list.forEach(function (col, i) {
        d[col] = +d[col];
      });
    });
     var statsDate = "30/01/2023";
     filtered = data.filter(function (d) {
        return d["date"] == statsDate;
      });
      
      var final_data = [];
      filtered.forEach(function (d, i) {
        var jsonData = {};
        jsonData["country_code"] = filtered[i]["iso_code"];
        jsonData["country_name"] = filtered[i]["location"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = "2023";
        jsonData["property_value"] = filtered[i]["total_cases"];
        
        //added new
         jsonData["continent"] = filtered[i]["continent"];
         jsonData["gdp_per_capita"] = filtered[i]["gdp_per_capita"];
         jsonData["total_deaths_per_million"] = filtered[i]["total_deaths_per_million"];
        final_data.push(jsonData);
      });
      return final_data;
  });
  return final_data;
}


function combinedPropertyHeaderStats(country_code) {
  property_list = ["total_cases"];

  final_data = Promise.all([
    propertyHeaderStatsPerCountryNew(property_list[0], country_code)
  ]).then(function (loadData) {
    property_1_data = loadData[0];
    return property_1_data;
  });

  console.log("Final Combined Data Per Country", final_data);
  return final_data;
}

function propertyHeaderStatsPerCountryNew(property_type, country_code) {
  csv_loc = findCsvLocNew("covid");
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
      "2023"
    ];

    data.forEach(function (d) {
      column_list.forEach(function (col, i) {
        d[col] = +d[col];
      });
    });
      filtered = data.filter(function (d) {
        return d["iso_code"] == country_code;
      });
      var final_data = [];
      column_list.forEach(function (col, i) {
		var statsDate = "30/01/"+col;
		property_data_country = filtered.filter(function (d) {
          return d["date"] == statsDate;
        });
        var jsonData = {};
        jsonData["country_code"] = property_data_country[0]["iso_code"];
        jsonData["country_name"] = property_data_country[0]["location"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = +col;
        jsonData["population"] = property_data_country[0]["population"];
        jsonData["total_cases"] = property_data_country[0]["total_cases"];
        jsonData["total_deaths"] = property_data_country[0]["total_deaths"];
        jsonData["people_fully_vaccinated"] = property_data_country[0]["people_fully_vaccinated"];
        jsonData["total_boosters"] = property_data_country[0]["total_boosters"];
        final_data.push(jsonData);
      });
      return final_data;
  });
  return final_data;
}


function combinedPropertyStatsPerCountryNew(country_code) {
  property_list = ["total_cases"];

  final_data = Promise.all([
    propertyStatsPerCountryNew(property_list[0], country_code)
  ]).then(function (loadData) {
    property_1_data = loadData[0];


    console.log("Combine data 1", property_1_data);

    return property_1_data;
  });

  console.log("Final Combined Data Per Country", final_data);
  return final_data;
}



function propertyStatsPerCountryNew(property_type, country_code) {
  csv_loc = findCsvLocNew("covid");
  final_data = d3.csv(csv_loc).then(function (data) {
    column_list = [
      "2020",
      "2021",
      "2022",
      "2023"
    ];

    data.forEach(function (d) {
      column_list.forEach(function (col, i) {
        d[col] = +d[col];
      });
    });

      filtered = data.filter(function (d) {
        return d["iso_code"] == country_code;
      });
      var final_data = [];
      column_list.forEach(function (col, i) {
		var statsDate = "30/01/"+col;
		property_data_country = filtered.filter(function (d) {
          return d["date"] == statsDate;
        });
        var jsonData = {};
        jsonData["country_code"] = filtered[0]["iso_code"];
        jsonData["country_name"] = filtered[0]["location"];
        jsonData["property_type"] = property_type;
        jsonData["property_year"] = +col;
        jsonData["property_value"] = +property_data_country[0]["total_cases"];
        final_data.push(jsonData);
      });
      return final_data;
    
  });
  return final_data;
}

